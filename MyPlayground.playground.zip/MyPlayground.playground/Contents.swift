// Import CreateMLUI to train the image classifier in the UI.
// For other Create ML tasks, import CreateML instead.
import CreateMLUI

let builder = MLImageClassifierBuilder()
builder.showInLiveView()
